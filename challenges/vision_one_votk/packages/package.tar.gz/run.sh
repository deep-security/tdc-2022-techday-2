#!/bin/bash

if [ "$REVERSE_MODE" = "true" ]
then
    echo "######################################################"
    echo "Starting Vision One on: "
    echo "$URL/index.html#/dashboard"
    echo "######################################################"
    #exec bash -c "mitmdump -p 80 --mode reverse:$URL/ -s /workspace/customlibs/frules.py --set frules_replay=rules.farx --set frules_replay_kill=false --set frules_replay_reverse=true"
    exec bash -c "mitmdump -p 80 --set block_global=false --mode reverse:http://127.0.0.1:8500 -s /opt/customlibs/frules.py --set frules_replay=rules.farx --set frules_replay_kill=false --set frules_replay_reverse=true --set frules_replay_reverse_body_url=$URL --set keep_host_header"
else
    echo "Running regular proxy mode"
    exec bash -c 'mitmdump -s /opt/customlibs/frules.py --set frules_replay=rules.farx --set frules_replay_kill=false --set keep_host_header'
fi