#!/bin/bash

/gotty --permit-write --credential player:superPassword1 --reconnect /bin/bash