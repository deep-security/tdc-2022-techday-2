**To delete block public access settings for an account**

The following ``delete-public-access-block`` example deletes block public access settings for the specified account. ::

    aws s3control delete-public-access-block \
        --account-id 123456789012

This command produces no output.
