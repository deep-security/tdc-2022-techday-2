**To delete an AWS Cost and Usage Report**

This example deletes an AWS Cost and Usage Report.

Command::

  aws cur --region us-east-1 delete-report-definition --report-name "ExampleReport"
